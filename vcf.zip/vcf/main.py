# from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect, Form
# from fastapi.staticfiles import StaticFiles
# from sqlalchemy.orm import Session
# from passlib.context import CryptContext
# import models, database, json

# models.Base.metadata.create_all(bind=database.engine)
# app = FastAPI()
# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# # Store active WebSockets: { "username": websocket }
# active_connections = {}

# def get_db():
#     db = database.SessionLocal()
#     try: yield db
#     finally: db.close()

# # --- Auth Routes ---
# @app.post("/register")
# def register(username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
#     if db.query(models.User).filter(models.User.username == username).first():
#         raise HTTPException(status_code=400, detail="Username exists")
#     new_user = models.User(username=username, hashed_password=pwd_context.hash(password))
#     db.add(new_user)
#     db.commit()
#     return {"status": "success"}

# @app.post("/login")
# def login(username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
#     user = db.query(models.User).filter(models.User.username == username).first()
#     if not user or not pwd_context.verify(password, user.hashed_password):
#         raise HTTPException(status_code=400, detail="Invalid credentials")
#     return {"username": username}

# # --- Signaling WebSocket ---
# @app.websocket("/ws/{username}")
# async def websocket_endpoint(websocket: WebSocket, username: str):
#     await websocket.accept()
#     active_connections[username] = websocket
#     try:
#         while True:
#             data = await websocket.receive_json()
#             target = data.get("target")
#             if target in active_connections:
#                 await active_connections[target].send_json({
#                     "from": username, "type": data["type"], "data": data["data"]
#                 })
#     except WebSocketDisconnect:
#         if username in active_connections: del active_connections[username]

# app.mount("/", StaticFiles(directory="public", html=True), name="public")

























from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect, Form
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from passlib.context import CryptContext
import models, database, json

models.Base.metadata.create_all(bind=database.engine)
app = FastAPI()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

active_connections = {}

def get_db():
    db = database.SessionLocal()
    try: yield db
    finally: db.close()

@app.post("/register")
def register(username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.username == username).first():
        raise HTTPException(status_code=400, detail="Username exists")
    new_user = models.User(username=username, hashed_password=pwd_context.hash(password))
    db.add(new_user)
    db.commit()
    return {"status": "success"}

@app.post("/login")
def login(username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user or not pwd_context.verify(password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    return {"username": username}

@app.websocket("/ws/{username}")
async def websocket_endpoint(websocket: WebSocket, username: str):
    await websocket.accept()
    active_connections[username] = websocket
    try:
        while True:
            data = await websocket.receive_json()
            target = data.get("target")
            if target in active_connections:
                await active_connections[target].send_json({
                    "from": username, "type": data["type"], "data": data["data"]
                })
    except WebSocketDisconnect:
        if username in active_connections: del active_connections[username]

app.mount("/", StaticFiles(directory="public", html=True), name="public")