


// let ws, pc, localStream, myName;

// // --- 1. Sound & Config ---
// // Using a standard public ringtone URL
// const ringtone = new Audio('https://www.soundjay.com/phone/phone-ringing-01.mp3');
// ringtone.loop = true;

// // const rtcConfig = { 
// //     iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] 
// // };
// const rtcConfig = { 
//     iceServers: [
//         { urls: 'stun:stun.l.google.com:19302' }, 
//         { 
//             urls: 'turn:global.relay.metered.ca:443', 
//             username: '127c38ee5b50fe695916ee83', // Use the one from your screenshot
//             credential: '6UX+ORYdNGMopNT4'       // Use the one from your screenshot
//         }
//     ] 
// };

// // --- 2. Authentication Logic ---
// async function auth(type) {
//     const user = document.getElementById('userIn').value;
//     const pass = document.getElementById('passIn').value;
//     if (!user || !pass) return alert("Please fill in all fields");

//     const formData = new FormData();
//     formData.append('username', user);
//     formData.append('password', pass);

//     try {
//         const res = await fetch(`/${type}`, { method: 'POST', body: formData });
//         if (res.ok) {
//             if (type === 'login') {
//                 myName = user;
//                 initCallSystem();
//             } else alert("Registered successfully! You can now Login.");
//         } else {
//             const err = await res.json();
//             alert("Error: " + (err.detail || "Authentication failed"));
//         }
//     } catch (e) {
//         alert("Server connection failed. Is your FastAPI server running?");
//     }
// }

// // --- 3. Signaling & Notification Setup ---
// function initCallSystem() {
//     document.getElementById('authSection').classList.add('hidden');
//     document.getElementById('callSection').classList.remove('hidden');
//     document.getElementById('hello').innerText = `Logged in as: ${myName}`;

//     // Request Notification Permission immediately upon login
//     if (Notification.permission === "default") {
//         Notification.requestPermission();
//     }

//     const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
//     ws = new WebSocket(`${protocol}//${window.location.host}/ws/${myName}`);

//     ws.onmessage = async (e) => {
//         const msg = JSON.parse(e.data);
//         if (msg.type === 'offer') handleOffer(msg);
//         else if (msg.type === 'answer') await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
//         else if (msg.type === 'candidate') await pc.addIceCandidate(new RTCIceCandidate(msg.data));
//         else if (msg.type === 'end') endCallLocally();
//     };
// }

// // --- 4. WebRTC Core ---
// async function preparePC(target) {
//     pc = new RTCPeerConnection(rtcConfig);
    
//     // Request Microphone access
//     localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
//     localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

//     // Listen for the remote audio stream
//     pc.ontrack = (e) => {
//         document.getElementById('remoteAudio').srcObject = e.streams[0];
//     };

//     // Handle network discovery (ICE candidates)
//     pc.onicecandidate = (e) => {
//         if (e.candidate) {
//             ws.send(JSON.stringify({ type: 'candidate', target, data: e.candidate }));
//         }
//     };

//     pc.onconnectionstatechange = () => {
//         if (pc.connectionState === 'disconnected' || pc.connectionState === 'closed') {
//             endCallLocally();
//         }
//     };
// }

// // --- 5. Handling Incoming Calls & Notifications ---
// async function handleOffer(msg) {
//     // Start ringtone
//     ringtone.play().catch(() => console.log("Audio waiting for user interaction"));

//     // Show System Notification
//     if (Notification.permission === "granted") {
//         const notification = new Notification("Incoming Call", {
//             body: `${msg.from} is calling you!`,
//             requireInteraction: true,
//             tag: "voice-call"
//         });
//         notification.onclick = () => { window.focus(); notification.close(); };
//     }

//     // Update UI Modal
//     document.getElementById('callerId').innerText = `Incoming call from: ${msg.from}`;
//     document.getElementById('incomingModal').classList.remove('hidden');

//     document.getElementById('acceptBtn').onclick = async () => {
//         ringtone.pause();
//         document.getElementById('incomingModal').classList.add('hidden');
        
//         await preparePC(msg.from);
//         await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
//         const answer = await pc.createAnswer();
//         await pc.setLocalDescription(answer);
        
//         // Send answer back through signaling server
//         ws.send(JSON.stringify({ type: 'answer', target: msg.from, data: answer }));
//     };
// }

// // --- 6. Call Controls (Start, Mute, End) ---
// async function startCall() {
//     const target = document.getElementById('targetIn').value;
//     if (!target) return alert("Please enter a username to call");
//     if (target === myName) return alert("You cannot call yourself!");
    
//     await preparePC(target);
//     const offer = await pc.createOffer();
//     await pc.setLocalDescription(offer);
    
//     // Send offer to signaling server
//     ws.send(JSON.stringify({ type: 'offer', target, data: offer }));
//     console.log("Calling " + target + "...");
// }

// function toggleMute() {
//     if (!localStream) return;
//     const audioTrack = localStream.getAudioTracks()[0];
//     audioTrack.enabled = !audioTrack.enabled;
//     document.getElementById('muteBtn').innerText = audioTrack.enabled ? "Mute Mic" : "Unmute Mic";
// }

// function hangUp() {
//     const target = document.getElementById('targetIn').value;
//     if (ws && target) {
//         ws.send(JSON.stringify({ type: 'end', target, data: null }));
//     }
//     endCallLocally();
// }

// function endCallLocally() {
//     if (pc) {
//         pc.close();
//         pc = null;
//     }
//     if (localStream) {
//         localStream.getTracks().forEach(track => track.stop());
//     }
//     ringtone.pause();
//     document.getElementById('incomingModal').classList.add('hidden');
//     document.getElementById('remoteAudio').srcObject = null;
//     console.log("Call disconnected.");
// }






































// let ws, pc, localStream, myName;

// // --- 1. Sound & TURN Config ---
// const ringtone = new Audio('https://www.soundjay.com/phone/phone-ringing-01.mp3');
// ringtone.loop = true;

// const rtcConfig = { 
//     iceServers: [
//         { urls: 'stun:stun.l.google.com:19302' }, 
//         { 
//             urls: 'turn:global.relay.metered.ca:443', 
//             username: '127c38ee5b50fe695916ee83', // From your dashboard
//             credential: '6UX+ORYdNGMopNT4'       // From your dashboard
//         }
//     ] 
// };

// // --- 2. Auth ---
// async function auth(type) {
//     const user = document.getElementById('userIn').value;
//     const pass = document.getElementById('passIn').value;
//     const formData = new FormData();
//     formData.append('username', user);
//     formData.append('password', pass);

//     const res = await fetch(`/${type}`, { method: 'POST', body: formData });
//     if (res.ok) {
//         if (type === 'login') { myName = user; initCallSystem(); }
//         else alert("Registration successful! Please login.");
//     } else alert("Error: Auth Failed");
// }

// // --- 3. Signaling ---
// function initCallSystem() {
//     document.getElementById('authSection').classList.add('hidden');
//     document.getElementById('callSection').classList.remove('hidden');
//     document.getElementById('hello').innerText = "Logged in as: " + myName;

//     if (Notification.permission === "default") Notification.requestPermission();

//     const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
//     ws = new WebSocket(`${protocol}//${window.location.host}/ws/${myName}`);

//     ws.onmessage = async (e) => {
//         const msg = JSON.parse(e.data);
//         if (msg.type === 'offer') handleOffer(msg);
//         else if (msg.type === 'answer') await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
//         else if (msg.type === 'candidate') await pc.addIceCandidate(new RTCIceCandidate(msg.data));
//         else if (msg.type === 'end') endCallLocally(); // Receive end signal
//     };
// }

// // --- 4. Call Handling ---
// async function preparePC(target) {
//     pc = new RTCPeerConnection(rtcConfig);
//     localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
//     localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
//     pc.ontrack = (e) => document.getElementById('remoteAudio').srcObject = e.streams[0];
//     pc.onicecandidate = (e) => e.candidate && ws.send(JSON.stringify({ type: 'candidate', target, data: e.candidate }));
// }

// async function startCall() {
//     const target = document.getElementById('targetIn').value;
//     await preparePC(target);
//     const offer = await pc.createOffer();
//     await pc.setLocalDescription(offer);
//     ws.send(JSON.stringify({ type: 'offer', target, data: offer }));
// }

// async function handleOffer(msg) {
//     ringtone.play().catch(() => {});
//     if (Notification.permission === "granted") {
//         new Notification("Incoming Call", { body: `${msg.from} is calling...` });
//     }
//     document.getElementById('callerId').innerText = msg.from + " is calling...";
//     document.getElementById('incomingModal').classList.remove('hidden');

//     document.getElementById('acceptBtn').onclick = async () => {
//         ringtone.pause();
//         document.getElementById('incomingModal').classList.add('hidden');
//         await preparePC(msg.from);
//         await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
//         const answer = await pc.createAnswer();
//         await pc.setLocalDescription(answer);
//         ws.send(JSON.stringify({ type: 'answer', target: msg.from, data: answer }));
//     };
// }

// // --- 5. Mute & End Call Logic ---
// function toggleMute() {
//     const track = localStream.getAudioTracks()[0];
//     track.enabled = !track.enabled;
//     document.getElementById('muteBtn').innerText = track.enabled ? "Mute Mic" : "Unmute Mic";
// }

// function hangUp() {
//     const target = document.getElementById('targetIn').value;
//     if (ws && target) {
//         ws.send(JSON.stringify({ type: 'end', target, data: null })); // Send end signal
//     }
//     endCallLocally();
// }

// function endCallLocally() {
//     if (pc) { pc.close(); pc = null; }
//     if (localStream) localStream.getTracks().forEach(t => t.stop());
//     ringtone.pause();
//     document.getElementById('incomingModal').classList.add('hidden');
//     document.getElementById('remoteAudio').srcObject = null;
//     alert("Call Ended");
// }
























let ws, pc, localStream, myName, currentRemoteUser;

// --- 1. Sound & TURN Config ---
const ringtone = new Audio('https://www.soundjay.com/phone/phone-ringing-01.mp3');
ringtone.loop = true;

const rtcConfig = { 
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' }, 
        { 
            // Your Metered.ca TURN credentials
            urls: 'turn:global.relay.metered.ca:443', 
            username: '127c38ee5b50fe695916ee83', 
            credential: '6UX+ORYdNGMopNT4'       
        }
    ] 
};

// --- 2. Authentication ---
async function auth(type) {
    const user = document.getElementById('userIn').value;
    const pass = document.getElementById('passIn').value;
    if (!user || !pass) return alert("Please fill in all fields");

    const formData = new FormData();
    formData.append('username', user);
    formData.append('password', pass);

    try {
        const res = await fetch(`/${type}`, { method: 'POST', body: formData });
        if (res.ok) {
            if (type === 'login') {
                myName = user;
                initCallSystem();
            } else alert("Registration successful! You can now Login.");
        } else {
            const err = await res.json();
            alert("Error: " + (err.detail || "Authentication failed"));
        }
    } catch (e) {
        alert("Server connection failed. Check if FastAPI is running.");
    }
}

// --- 3. Signaling & Notification Setup ---
function initCallSystem() {
    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('callSection').classList.remove('hidden');
    document.getElementById('hello').innerText = `Logged in as: ${myName}`;

    if (Notification.permission === "default") {
        Notification.requestPermission();
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    ws = new WebSocket(`${protocol}//${window.location.host}/ws/${myName}`);

    ws.onmessage = async (e) => {
        const msg = JSON.parse(e.data);
        if (msg.type === 'offer') handleOffer(msg);
        else if (msg.type === 'answer') await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
        else if (msg.type === 'candidate') await pc.addIceCandidate(new RTCIceCandidate(msg.data));
        else if (msg.type === 'end') {
            console.log("Call ended by remote user");
            endCallLocally(); // Triggers on both sides
        }
    };
}

// --- 4. WebRTC Core ---
async function preparePC(target) {
    pc = new RTCPeerConnection(rtcConfig);
    
    localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));

    pc.ontrack = (e) => {
        document.getElementById('remoteAudio').srcObject = e.streams[0];
    };

    pc.onicecandidate = (e) => {
        if (e.candidate) {
            ws.send(JSON.stringify({ type: 'candidate', target, data: e.candidate }));
        }
    };

    pc.onconnectionstatechange = () => {
        if (pc.connectionState === 'disconnected' || pc.connectionState === 'closed') {
            endCallLocally();
        }
    };
}

// --- 5. Handling Calls & Notifications ---
async function startCall() {
    const target = document.getElementById('targetIn').value;
    if (!target) return alert("Please enter a username to call");
    if (target === myName) return alert("You cannot call yourself!");
    
    currentRemoteUser = target; // Save target globally
    await preparePC(target);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    
    ws.send(JSON.stringify({ type: 'offer', target, data: offer }));
    console.log("Calling " + target + "...");
}

async function handleOffer(msg) {
    currentRemoteUser = msg.from; // Save caller globally
    ringtone.play().catch(() => {});

    if (Notification.permission === "granted") {
        const notification = new Notification("Incoming Call", {
            body: `${msg.from} is calling you!`,
            requireInteraction: true,
            tag: "voice-call"
        });
        notification.onclick = () => { window.focus(); notification.close(); };
    }

    document.getElementById('callerId').innerText = `Incoming call from: ${msg.from}`;
    document.getElementById('incomingModal').classList.remove('hidden');

    document.getElementById('acceptBtn').onclick = async () => {
        ringtone.pause();
        document.getElementById('incomingModal').classList.add('hidden');
        
        await preparePC(msg.from);
        await pc.setRemoteDescription(new RTCSessionDescription(msg.data));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        
        ws.send(JSON.stringify({ type: 'answer', target: msg.from, data: answer }));
    };
}

// --- 6. Controls (Mute/Hangup) ---
function toggleMute() {
    if (!localStream) return;
    const audioTrack = localStream.getAudioTracks()[0];
    audioTrack.enabled = !audioTrack.enabled;
    document.getElementById('muteBtn').innerText = audioTrack.enabled ? "Mute Mic" : "Unmute Mic";
}

function hangUp() {
    if (ws && currentRemoteUser) {
        // Send signal to specific person
        ws.send(JSON.stringify({ type: 'end', target: currentRemoteUser, data: null }));
    }
    endCallLocally();
}

function endCallLocally() {
    if (pc) {
        pc.close();
        pc = null;
    }
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
    }
    ringtone.pause();
    document.getElementById('incomingModal').classList.add('hidden');
    document.getElementById('remoteAudio').srcObject = null;
    currentRemoteUser = null; // Reset global state
    alert("Call Ended");
}